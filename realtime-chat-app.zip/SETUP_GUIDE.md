# Real-Time Chat Application - Setup & Deployment Guide

A free, fully functional web-based real-time chat application similar to WhatsApp. This guide covers everything from local development to free deployment.

## Features

- **User Authentication**: Sign up and login with email and password
- **Real-Time Messaging**: Send and receive messages instantly
- **Message History**: All messages are stored and visible when users log in
- **User List**: See all users with online/offline status
- **WhatsApp-like UI**: Modern, clean interface with glassmorphic design
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Demo Accounts**: Pre-loaded demo users for testing

## Tech Stack

- **Frontend**: React 19 + TypeScript + Tailwind CSS
- **Storage**: Browser LocalStorage (for demo) + Firebase Firestore (for production)
- **Authentication**: Firebase Authentication (production) or Local Auth (demo)
- **Hosting**: Firebase Hosting (free tier)
- **Build Tool**: Vite

## Demo Credentials

Try the app with these pre-loaded accounts:

| Email | Password |
|-------|----------|
| alice@example.com | password123 |
| bob@example.com | password123 |
| charlie@example.com | password123 |

## Local Development Setup

### Prerequisites

- Node.js 18+ and npm/pnpm
- Git
- A code editor (VS Code recommended)

### Installation Steps

1. **Clone or download the project**
   ```bash
   cd realtime-chat-app
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   # or
   npm install
   ```

3. **Start the development server**
   ```bash
   pnpm dev
   # or
   npm run dev
   ```

4. **Open in browser**
   - Navigate to `http://localhost:3000`
   - Log in with demo credentials above

### Project Structure

```
realtime-chat-app/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── LoginPage.tsx          # Login page
│   │   │   ├── SignupPage.tsx         # Sign up page
│   │   │   └── ChatPage.tsx           # Main chat interface
│   │   ├── contexts/
│   │   │   └── LocalAuthContext.tsx   # Authentication context
│   │   ├── lib/
│   │   │   └── storage.ts             # Local storage service
│   │   ├── components/
│   │   │   └── ui/                    # shadcn/ui components
│   │   ├── App.tsx                    # Main app component
│   │   ├── main.tsx                   # React entry point
│   │   └── index.css                  # Global styles
│   ├── public/                         # Static assets
│   └── index.html                      # HTML entry point
├── package.json                        # Dependencies
└── SETUP_GUIDE.md                      # This file
```

## Customization

### Add More Demo Users

Edit `client/src/lib/storage.ts` and add users to the `demoUsers` array:

```typescript
const demoUsers: User[] = [
  {
    id: 'demo1',
    username: 'Alice',
    email: 'alice@example.com',
    password: 'password123',
    createdAt: Date.now(),
    lastSeen: Date.now(),
    status: 'online',
  },
  // Add more users here
];
```

### Change Colors

Edit `client/src/index.css` to modify the color scheme. The app uses teal and coral colors by default:

```css
:root {
  --primary: var(--color-teal-700);  /* Change primary color */
  --accent: var(--color-coral-500);  /* Change accent color */
}
```

### Modify UI

All UI components are in `client/src/components/` and pages are in `client/src/pages/`. Edit these files to customize the interface.

## Production Deployment

### Option 1: Deploy to Firebase Hosting (Recommended - Free)

Firebase Hosting offers a free tier with generous limits. Follow these steps:

#### Step 1: Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add Project"
3. Enter project name and accept terms
4. Disable Google Analytics (optional)
5. Click "Create Project"

#### Step 2: Set Up Firebase Hosting

1. In Firebase Console, go to "Hosting" in the left menu
2. Click "Get Started"
3. Install Firebase CLI:
   ```bash
   npm install -g firebase-tools
   ```

4. Log in to Firebase:
   ```bash
   firebase login
   ```

5. Initialize Firebase in your project:
   ```bash
   firebase init hosting
   ```
   - Select your Firebase project
   - Set public directory to `dist`
   - Choose "No" for single-page app configuration
   - Choose "No" to overwrite dist/index.html

#### Step 3: Build and Deploy

1. Build the project:
   ```bash
   pnpm build
   # or
   npm run build
   ```

2. Deploy to Firebase:
   ```bash
   firebase deploy
   ```

3. Your app will be live at: `https://your-project-id.web.app`

### Option 2: Deploy to Vercel (Free)

1. Push your code to GitHub
2. Go to [Vercel](https://vercel.com/)
3. Click "New Project"
4. Import your GitHub repository
5. Click "Deploy"
6. Your app will be live at a Vercel URL

### Option 3: Deploy to Netlify (Free)

1. Push your code to GitHub
2. Go to [Netlify](https://netlify.com/)
3. Click "New site from Git"
4. Connect your GitHub account
5. Select your repository
6. Build command: `pnpm build`
7. Publish directory: `dist`
8. Click "Deploy"

## Production Setup with Firebase Backend

For a production app with real Firebase backend:

### Step 1: Set Up Firebase Firestore

1. In Firebase Console, go to "Firestore Database"
2. Click "Create Database"
3. Choose "Start in test mode"
4. Select a region close to your users
5. Click "Create"

### Step 2: Update Firebase Configuration

1. In Firebase Console, go to "Project Settings"
2. Scroll to "Your apps" and click the web icon
3. Copy the Firebase config
4. Update `client/src/lib/firebase.ts`:

```typescript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### Step 3: Update Authentication Context

Replace `LocalAuthContext.tsx` with Firebase authentication:

```typescript
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth } from '@/lib/firebase';

export function useLocalAuth() {
  const [user, loading] = useAuthState(auth);
  // ... implement Firebase auth methods
}
```

### Step 4: Update Message Storage

Replace local storage with Firestore in `ChatPage.tsx`:

```typescript
import { collection, addDoc, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase';

// Use Firestore instead of localStorage
```

## Troubleshooting

### Issue: "Module not found" errors

**Solution**: Run `pnpm install` to install all dependencies

### Issue: Port 3000 already in use

**Solution**: 
```bash
# Kill the process on port 3000
lsof -ti:3000 | xargs kill -9

# Or use a different port
pnpm dev -- --port 3001
```

### Issue: Build fails

**Solution**: 
```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm build
```

### Issue: Messages not persisting

**Solution**: Check browser console for errors. LocalStorage has a 5-10MB limit. For production, use Firebase Firestore.

## Free Tier Limits

### Firebase Hosting (Free)
- 1 GB storage
- 10 GB/month bandwidth
- Custom domain support
- SSL certificate included

### Firebase Firestore (Free)
- 1 GB storage
- 50,000 reads/day
- 20,000 writes/day
- 20,000 deletes/day

### Firebase Authentication (Free)
- Unlimited users
- No cost for authentication

## Next Steps

1. **Test locally** with demo accounts
2. **Customize** colors, fonts, and branding
3. **Add more features** like file sharing, typing indicators, etc.
4. **Deploy** to Firebase Hosting or your preferred platform
5. **Monitor** usage in Firebase Console

## Support & Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [React Documentation](https://react.dev)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [Vite Documentation](https://vitejs.dev)

## License

This project is open source and available under the MIT License.

---

**Happy Chatting! 🎉**
