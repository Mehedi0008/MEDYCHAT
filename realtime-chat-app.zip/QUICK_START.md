# Quick Start Guide

Get your real-time chat app running in 5 minutes!

## 🚀 Start Locally (2 minutes)

### Step 1: Install Dependencies
```bash
cd realtime-chat-app
pnpm install
```

### Step 2: Run Development Server
```bash
pnpm dev
```

### Step 3: Open in Browser
```
http://localhost:3000
```

### Step 4: Log In with Demo Account
```
Email: alice@example.com
Password: password123
```

**That's it!** You now have a fully functional chat app running locally.

---

## 👥 Try Multi-User Chat

Open two browser windows/tabs:

1. **Tab 1**: Log in as Alice (alice@example.com)
2. **Tab 2**: Log in as Bob (bob@example.com)
3. Send messages between them in real-time!

**Demo Accounts Available:**
- alice@example.com / password123
- bob@example.com / password123
- charlie@example.com / password123

---

## 🌐 Deploy to Web (5 minutes)

### Option A: Firebase Hosting (Free, Recommended)

```bash
# 1. Install Firebase CLI
npm install -g firebase-tools

# 2. Login to Firebase
firebase login

# 3. Initialize Firebase
firebase init hosting

# 4. Build the project
pnpm build

# 5. Deploy
firebase deploy
```

✅ Your app is now live at: `https://your-project-id.web.app`

### Option B: Vercel (Free, Easiest)

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Select your GitHub repo
5. Click "Deploy"

✅ Your app is live instantly!

### Option C: Netlify (Free)

1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Click "New site from Git"
4. Select your GitHub repo
5. Build command: `pnpm build`
6. Publish directory: `dist`
7. Click "Deploy"

✅ Your app is live!

---

## 🎯 Key Features to Try

### 1. Create Account
Click "Sign Up" to create a new account with any email/password

### 2. Search Users
Use the search box in the sidebar to find users by name or email

### 3. Send Messages
Select a user and type a message - it appears instantly!

### 4. View History
All messages are saved - they appear when you log back in

### 5. Online Status
Green dot indicates online users, gray dot for offline

---

## 🔧 Customize Your App

### Change App Name
Edit `client/index.html`:
```html
<title>My Chat App</title>
```

### Change Colors
Edit `client/src/index.css` - look for color definitions

### Add More Users
Edit `client/src/lib/storage.ts` - add users to the demo data

### Change Welcome Message
Edit `client/src/pages/ChatPage.tsx` - modify the empty state text

---

## 📱 Mobile Access

Your app works on mobile! 

1. Deploy to Firebase/Vercel/Netlify
2. Open the URL on your phone
3. Chat from anywhere!

---

## ❓ Common Questions

### Q: Where are messages stored?
**A:** Locally in your browser (demo) or Firebase Firestore (production)

### Q: Can I use real Firebase?
**A:** Yes! See SETUP_GUIDE.md for Firebase backend setup

### Q: How many users can I have?
**A:** Unlimited with Firebase free tier

### Q: Is it secure?
**A:** Demo version is for testing. Production version uses Firebase security

### Q: Can I add more features?
**A:** Yes! The code is fully customizable

---

## 🆘 Troubleshooting

**Port 3000 already in use?**
```bash
lsof -ti:3000 | xargs kill -9
pnpm dev
```

**Dependencies not installing?**
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

**Build fails?**
```bash
pnpm clean
pnpm install
pnpm build
```

---

## 📚 Next Steps

1. ✅ Run locally
2. ✅ Test with demo accounts
3. ✅ Deploy to the web
4. ✅ Customize colors and branding
5. ✅ Add your own features
6. ✅ Share with friends!

---

## 🎉 You're All Set!

Your real-time chat app is ready to go. Happy chatting!

For detailed information, see [SETUP_GUIDE.md](./SETUP_GUIDE.md) and [README.md](./README.md)
