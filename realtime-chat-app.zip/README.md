# Real-Time Chat Application

A free, fully functional web-based real-time chat application similar to WhatsApp. Built with React, TypeScript, and Tailwind CSS.

## 🚀 Quick Start

### Demo Credentials
```
Email: alice@example.com | Password: password123
Email: bob@example.com | Password: password123
Email: charlie@example.com | Password: password123
```

### Local Development
```bash
# Install dependencies
pnpm install

# Start dev server
pnpm dev

# Open http://localhost:3000
```

## ✨ Features

- ✅ User authentication (signup/login)
- ✅ Real-time messaging
- ✅ Message history persistence
- ✅ User list with online/offline status
- ✅ WhatsApp-like UI with glassmorphic design
- ✅ Responsive design (mobile, tablet, desktop)
- ✅ Date-grouped message display
- ✅ Typing indicators
- ✅ User search functionality

## 📱 Screenshots

The app features a modern split-screen layout with:
- **Left Sidebar**: User list with search and online status
- **Main Chat Area**: Message history with timestamps
- **Message Input**: Send messages with real-time updates

## 🛠️ Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19 + TypeScript |
| Styling | Tailwind CSS 4 + shadcn/ui |
| State Management | React Context API |
| Storage | Browser LocalStorage (demo) / Firebase Firestore (production) |
| Authentication | Local Auth (demo) / Firebase Auth (production) |
| Build Tool | Vite |
| Hosting | Firebase Hosting / Vercel / Netlify |

## 📁 Project Structure

```
client/src/
├── pages/
│   ├── LoginPage.tsx       # User login
│   ├── SignupPage.tsx      # User registration
│   └── ChatPage.tsx        # Main chat interface
├── contexts/
│   └── LocalAuthContext.tsx # Auth state management
├── lib/
│   └── storage.ts          # Local storage service
├── components/
│   └── ui/                 # shadcn/ui components
├── App.tsx                 # Main app component
└── index.css               # Global styles
```

## 🚀 Deployment

### Firebase Hosting (Recommended)
```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize and deploy
firebase init hosting
pnpm build
firebase deploy
```

### Vercel
1. Push to GitHub
2. Import repository in Vercel
3. Deploy automatically

### Netlify
1. Push to GitHub
2. Connect to Netlify
3. Deploy automatically

See [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed instructions.

## 🎨 Design Philosophy

The application uses a **Modern Minimalist with Glassmorphism** design approach:

- **Color Scheme**: Teal (#0D9488) primary, Coral (#FF6B6B) accent
- **Layout**: Asymmetric split-screen (sidebar + main area)
- **Effects**: Glassmorphic panels with backdrop blur
- **Typography**: Clean, hierarchical font system
- **Animations**: Smooth transitions and micro-interactions

## 🔧 Customization

### Add Demo Users
Edit `client/src/lib/storage.ts`:
```typescript
const demoUsers: User[] = [
  // Add your users here
];
```

### Change Colors
Edit `client/src/index.css`:
```css
:root {
  --primary: #0D9488;  /* Change primary color */
  --accent: #FF6B6B;   /* Change accent color */
}
```

### Modify UI
- Pages: `client/src/pages/`
- Components: `client/src/components/`
- Styles: `client/src/index.css`

## 📊 Data Structure

### User Object
```typescript
interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  createdAt: number;
  lastSeen: number;
  status: 'online' | 'offline';
}
```

### Message Object
```typescript
interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  text: string;
  timestamp: number;
  read: boolean;
}
```

## 🔐 Security Notes

**Demo Version**: Uses LocalStorage with plain text passwords (for demo only)

**Production Version**: 
- Use Firebase Authentication (never store passwords client-side)
- Enable Firestore security rules
- Use HTTPS only
- Implement rate limiting
- Add input validation and sanitization

## 📈 Scalability

### Current Limits (LocalStorage)
- Max 5-10MB per browser
- Limited to single device
- No sync across devices

### Production (Firebase)
- Unlimited storage
- Real-time sync
- Cross-device access
- Automatic backups

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Port 3000 in use | `lsof -ti:3000 \| xargs kill -9` |
| Module not found | `pnpm install` |
| Build fails | `rm -rf node_modules && pnpm install` |
| Messages not saving | Check browser console for errors |

## 📚 Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [React Documentation](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [Vite Documentation](https://vitejs.dev)

## 🤝 Contributing

Feel free to fork, modify, and improve this project!

## 📄 License

MIT License - feel free to use this project for personal or commercial purposes.

---

**Built with ❤️ using React and Firebase**
