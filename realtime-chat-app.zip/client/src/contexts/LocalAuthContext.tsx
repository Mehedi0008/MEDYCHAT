import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, StorageService } from '@/lib/storage';

interface LocalAuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const LocalAuthContext = createContext<LocalAuthContextType | undefined>(undefined);

export function LocalAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const currentUser = StorageService.getCurrentUser();
    setUser(currentUser);
    setLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const loggedInUser = StorageService.login(email, password);
      if (loggedInUser) {
        setUser(loggedInUser);
        return true;
      } else {
        setError('Invalid email or password');
        return false;
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const signup = async (username: string, email: string, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const newUser = StorageService.createUser(username, email, password);
      if (newUser) {
        setUser(newUser);
        StorageService.setCurrentUser(newUser);
        return true;
      } else {
        setError('Username or email already exists');
        return false;
      }
    } catch (err: any) {
      setError(err.message || 'Signup failed');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    StorageService.logout();
    setUser(null);
    setError(null);
  };

  return (
    <LocalAuthContext.Provider value={{ user, loading, error, login, signup, logout }}>
      {children}
    </LocalAuthContext.Provider>
  );
}

export function useLocalAuth() {
  const context = useContext(LocalAuthContext);
  if (context === undefined) {
    throw new Error('useLocalAuth must be used within a LocalAuthProvider');
  }
  return context;
}
