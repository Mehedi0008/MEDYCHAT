/**
 * Local Storage Service
 * Manages users, authentication, and messages using browser localStorage
 * In production, replace with Firebase or a backend API
 */

export interface User {
  id: string;
  username: string;
  email: string;
  password: string; // In production, never store passwords client-side
  createdAt: number;
  lastSeen: number;
  status: 'online' | 'offline';
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  text: string;
  timestamp: number;
  read: boolean;
}

export interface Conversation {
  id: string;
  participants: string[];
  lastMessage: string;
  lastMessageTime: number;
}

const USERS_KEY = 'chat_users';
const MESSAGES_KEY = 'chat_messages';
const CONVERSATIONS_KEY = 'chat_conversations';
const CURRENT_USER_KEY = 'chat_current_user';

// Initialize with demo users
function initializeDemoData() {
  const existingUsers = localStorage.getItem(USERS_KEY);
  if (!existingUsers) {
    const demoUsers: User[] = [
      {
        id: 'demo1',
        username: 'Alice',
        email: 'alice@example.com',
        password: 'password123',
        createdAt: Date.now(),
        lastSeen: Date.now(),
        status: 'online',
      },
      {
        id: 'demo2',
        username: 'Bob',
        email: 'bob@example.com',
        password: 'password123',
        createdAt: Date.now(),
        lastSeen: Date.now(),
        status: 'online',
      },
      {
        id: 'demo3',
        username: 'Charlie',
        email: 'charlie@example.com',
        password: 'password123',
        createdAt: Date.now(),
        lastSeen: Date.now(),
        status: 'offline',
      },
    ];
    localStorage.setItem(USERS_KEY, JSON.stringify(demoUsers));
  }
}

export const StorageService = {
  // User Management
  getAllUsers(): User[] {
    initializeDemoData();
    const users = localStorage.getItem(USERS_KEY);
    return users ? JSON.parse(users) : [];
  },

  getUserById(id: string): User | null {
    const users = this.getAllUsers();
    return users.find(u => u.id === id) || null;
  },

  getUserByEmail(email: string): User | null {
    const users = this.getAllUsers();
    return users.find(u => u.email === email) || null;
  },

  getUserByUsername(username: string): User | null {
    const users = this.getAllUsers();
    return users.find(u => u.username === username) || null;
  },

  createUser(username: string, email: string, password: string): User | null {
    // Check if user already exists
    if (this.getUserByEmail(email) || this.getUserByUsername(username)) {
      return null;
    }

    const newUser: User = {
      id: 'user_' + Date.now(),
      username,
      email,
      password,
      createdAt: Date.now(),
      lastSeen: Date.now(),
      status: 'online',
    };

    const users = this.getAllUsers();
    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return newUser;
  },

  updateUserStatus(userId: string, status: 'online' | 'offline') {
    const users = this.getAllUsers();
    const user = users.find(u => u.id === userId);
    if (user) {
      user.status = status;
      user.lastSeen = Date.now();
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
  },

  // Authentication
  login(email: string, password: string): User | null {
    const user = this.getUserByEmail(email);
    if (user && user.password === password) {
      this.setCurrentUser(user);
      this.updateUserStatus(user.id, 'online');
      return user;
    }
    return null;
  },

  logout() {
    const currentUser = this.getCurrentUser();
    if (currentUser) {
      this.updateUserStatus(currentUser.id, 'offline');
    }
    localStorage.removeItem(CURRENT_USER_KEY);
  },

  getCurrentUser(): User | null {
    const user = localStorage.getItem(CURRENT_USER_KEY);
    return user ? JSON.parse(user) : null;
  },

  setCurrentUser(user: User) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  },

  // Messages
  getAllMessages(): Message[] {
    const messages = localStorage.getItem(MESSAGES_KEY);
    return messages ? JSON.parse(messages) : [];
  },

  getConversationMessages(conversationId: string): Message[] {
    const messages = this.getAllMessages();
    return messages
      .filter(m => m.conversationId === conversationId)
      .sort((a, b) => a.timestamp - b.timestamp);
  },

  sendMessage(senderId: string, senderName: string, receiverId: string, text: string): Message {
    const conversationId = [senderId, receiverId].sort().join('_');
    
    const message: Message = {
      id: 'msg_' + Date.now(),
      conversationId,
      senderId,
      senderName,
      receiverId,
      text,
      timestamp: Date.now(),
      read: false,
    };

    const messages = this.getAllMessages();
    messages.push(message);
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(messages));

    // Update or create conversation
    this.updateConversation(conversationId, [senderId, receiverId], text);

    return message;
  },

  // Conversations
  getAllConversations(): Conversation[] {
    const conversations = localStorage.getItem(CONVERSATIONS_KEY);
    return conversations ? JSON.parse(conversations) : [];
  },

  getConversation(conversationId: string): Conversation | null {
    const conversations = this.getAllConversations();
    return conversations.find(c => c.id === conversationId) || null;
  },

  updateConversation(conversationId: string, participants: string[], lastMessage: string) {
    const conversations = this.getAllConversations();
    const existing = conversations.find(c => c.id === conversationId);

    if (existing) {
      existing.lastMessage = lastMessage;
      existing.lastMessageTime = Date.now();
    } else {
      conversations.push({
        id: conversationId,
        participants,
        lastMessage,
        lastMessageTime: Date.now(),
      });
    }

    localStorage.setItem(CONVERSATIONS_KEY, JSON.stringify(conversations));
  },

  getUserConversations(userId: string): Conversation[] {
    const conversations = this.getAllConversations();
    return conversations
      .filter(c => c.participants.includes(userId))
      .sort((a, b) => b.lastMessageTime - a.lastMessageTime);
  },
};
