import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useLocalAuth } from '@/contexts/LocalAuthContext';
import { StorageService, User, Message } from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LogOut, Send, Search } from 'lucide-react';
import { toast } from 'sonner';

export default function ChatPage() {
  const [, setLocation] = useLocation();
  const { user, logout } = useLocalAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      setLocation('/login');
    }
  }, [user, setLocation]);

  // Load all users
  useEffect(() => {
    if (!user) return;

    const allUsers = StorageService.getAllUsers();
    const otherUsers = allUsers.filter(u => u.id !== user.id);
    setUsers(otherUsers);

    // Refresh users every 2 seconds to update status
    const interval = setInterval(() => {
      const updatedUsers = StorageService.getAllUsers();
      const otherUsers = updatedUsers.filter(u => u.id !== user.id);
      setUsers(otherUsers);
    }, 2000);

    return () => clearInterval(interval);
  }, [user]);

  // Load messages for selected user
  useEffect(() => {
    if (!user || !selectedUser) return;

    const conversationId = [user.id, selectedUser.id].sort().join('_');
    const conversationMessages = StorageService.getConversationMessages(conversationId);
    setMessages(conversationMessages);

    // Poll for new messages every 1 second
    const interval = setInterval(() => {
      const updatedMessages = StorageService.getConversationMessages(conversationId);
      setMessages(updatedMessages);
    }, 1000);

    return () => clearInterval(interval);
  }, [user, selectedUser]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !user || !selectedUser) return;

    setSendingMessage(true);
    try {
      StorageService.sendMessage(
        user.id,
        user.username,
        selectedUser.id,
        messageText
      );
      setMessageText('');
      toast.success('Message sent!');
    } catch (error: any) {
      toast.error('Failed to send message');
    } finally {
      setSendingMessage(false);
    }
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    setLocation('/login');
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  const filteredUsers = users.filter(u =>
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const today = new Date();

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    }

    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }

    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined,
    });
  };

  // Group messages by date
  const groupedMessages = messages.reduce((acc, msg) => {
    const dateKey = formatDate(msg.timestamp);
    if (!acc[dateKey]) {
      acc[dateKey] = [];
    }
    acc[dateKey].push(msg);
    return acc;
  }, {} as Record<string, Message[]>);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
      <div className="flex h-screen">
        {/* Sidebar - User List */}
        <div className="w-80 border-r border-slate-200 bg-white/50 backdrop-blur-sm flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-bold text-slate-900">Chats</h1>
              <Button
                onClick={handleLogout}
                size="sm"
                variant="ghost"
                className="text-slate-600 hover:text-slate-900"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>

            {/* User Info */}
            <div className="bg-gradient-to-r from-teal-50 to-teal-100 rounded-lg p-3 mb-4">
              <p className="text-xs text-slate-600">Logged in as</p>
              <p className="font-semibold text-slate-900">{user.username}</p>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-100 border-0 text-sm"
              />
            </div>
          </div>

          {/* Users List */}
          <ScrollArea className="flex-1">
            <div className="p-2">
              {filteredUsers.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <p className="text-sm">No users found</p>
                </div>
              ) : (
                filteredUsers.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => setSelectedUser(u)}
                    className={`w-full text-left p-3 rounded-lg mb-2 transition-all ${
                      selectedUser?.id === u.id
                        ? 'bg-gradient-to-r from-teal-100 to-teal-50 border border-teal-200'
                        : 'hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white font-semibold mr-3">
                        {u.username.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-900 truncate">{u.username}</p>
                        <p className="text-xs text-slate-500 truncate">{u.email}</p>
                      </div>
                      {u.status === 'online' && (
                        <div className="w-2 h-2 bg-green-500 rounded-full ml-2 animate-pulse"></div>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col bg-white/30 backdrop-blur-sm">
          {selectedUser ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-slate-200 bg-white/50 backdrop-blur-sm">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white font-semibold mr-3">
                    {selectedUser.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{selectedUser.username}</p>
                    <p className="text-xs text-slate-500">
                      {selectedUser.status === 'online' ? 'Online' : 'Offline'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-slate-500">
                      <p>No messages yet. Start the conversation!</p>
                    </div>
                  ) : (
                    Object.entries(groupedMessages).map(([date, dateMessages]) => (
                      <div key={date}>
                        {/* Date separator */}
                        <div className="flex items-center justify-center my-4">
                          <div className="flex-1 border-t border-slate-200"></div>
                          <span className="px-3 text-xs text-slate-500 bg-white/50 rounded-full">
                            {date}
                          </span>
                          <div className="flex-1 border-t border-slate-200"></div>
                        </div>

                        {/* Messages for this date */}
                        <div className="space-y-2">
                          {dateMessages.map((msg) => (
                            <div
                              key={msg.id}
                              className={`flex ${
                                msg.senderId === user.id ? 'justify-end' : 'justify-start'
                              }`}
                            >
                              <div
                                className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                  msg.senderId === user.id
                                    ? 'bg-gradient-to-br from-teal-500 to-teal-600 text-white rounded-br-none'
                                    : 'bg-white/70 backdrop-blur-sm text-slate-900 rounded-bl-none border border-slate-200'
                                }`}
                              >
                                {msg.senderId !== user.id && (
                                  <p className="text-xs font-semibold text-slate-600 mb-1">
                                    {msg.senderName}
                                  </p>
                                )}
                                <p className="break-words">{msg.text}</p>
                                <p
                                  className={`text-xs mt-1 ${
                                    msg.senderId === user.id
                                      ? 'text-teal-100'
                                      : 'text-slate-500'
                                  }`}
                                >
                                  {formatTime(msg.timestamp)}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              {/* Message Input */}
              <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 bg-white/50 backdrop-blur-sm">
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Type a message..."
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    disabled={sendingMessage}
                    className="flex-1"
                  />
                  <Button
                    type="submit"
                    disabled={sendingMessage || !messageText.trim()}
                    className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-teal-100 to-teal-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </div>
                <p className="text-slate-600 font-medium">Select a user to start chatting</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
