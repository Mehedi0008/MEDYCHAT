import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useLocalAuth } from '@/contexts/LocalAuthContext';
import { StorageService, User, Message } from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LogOut, Send, Search, ChevronLeft, Menu, X } from 'lucide-react';
import { toast } from 'sonner';

export default function ChatPageMobile() {
  const [, setLocation] = useLocation();
  const { user, logout } = useLocalAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [showUserList, setShowUserList] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      setLocation('/login');
    }
  }, [user, setLocation]);

  // Load all users
  useEffect(() => {
    if (!user) return;

    const allUsers = StorageService.getAllUsers();
    const otherUsers = allUsers.filter(u => u.id !== user.id);
    setUsers(otherUsers);

    const interval = setInterval(() => {
      const updatedUsers = StorageService.getAllUsers();
      const otherUsers = updatedUsers.filter(u => u.id !== user.id);
      setUsers(otherUsers);
    }, 2000);

    return () => clearInterval(interval);
  }, [user]);

  // Load messages for selected user
  useEffect(() => {
    if (!user || !selectedUser) return;

    const conversationId = [user.id, selectedUser.id].sort().join('_');
    const conversationMessages = StorageService.getConversationMessages(conversationId);
    setMessages(conversationMessages);

    const interval = setInterval(() => {
      const updatedMessages = StorageService.getConversationMessages(conversationId);
      setMessages(updatedMessages);
    }, 1000);

    return () => clearInterval(interval);
  }, [user, selectedUser]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !user || !selectedUser) return;

    setSendingMessage(true);
    try {
      StorageService.sendMessage(
        user.id,
        user.username,
        selectedUser.id,
        messageText
      );
      setMessageText('');
      inputRef.current?.focus();
      toast.success('Message sent!');
    } catch (error: any) {
      toast.error('Failed to send message');
    } finally {
      setSendingMessage(false);
    }
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    setLocation('/login');
  };

  const handleSelectUser = (u: User) => {
    setSelectedUser(u);
    setShowUserList(false);
  };

  const handleBackToList = () => {
    setShowUserList(true);
    setSelectedUser(null);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  const filteredUsers = users.filter(u =>
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const today = new Date();

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    }

    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }

    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const groupedMessages = messages.reduce((acc, msg) => {
    const dateKey = formatDate(msg.timestamp);
    if (!acc[dateKey]) {
      acc[dateKey] = [];
    }
    acc[dateKey].push(msg);
    return acc;
  }, {} as Record<string, Message[]>);

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50 flex flex-col md:flex-row overflow-hidden safe-area-top safe-area-bottom">
      {/* Mobile User List - Responsive */}
      <div
        className={`absolute md:relative w-full md:w-80 h-full md:h-auto border-r border-slate-200 bg-white/50 backdrop-blur-sm flex flex-col transition-transform duration-300 z-40 ${
          showUserList ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 safe-area-left safe-area-right">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl md:text-2xl font-bold text-slate-900">Chats</h1>
            <Button
              onClick={handleLogout}
              size="sm"
              variant="ghost"
              className="text-slate-600 hover:text-slate-900 touch-target"
            >
              <LogOut className="w-5 h-5" />
            </Button>
          </div>

          {/* User Info */}
          <div className="bg-gradient-to-r from-teal-50 to-teal-100 rounded-lg p-3 mb-4">
            <p className="text-xs text-slate-600">Logged in as</p>
            <p className="font-semibold text-slate-900 truncate">{user.username}</p>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
            <Input
              type="text"
              placeholder="Search users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-100 border-0 text-sm touch-target"
            />
          </div>
        </div>

        {/* Users List */}
        <ScrollArea className="flex-1">
          <div className="p-2 safe-area-left safe-area-right">
            {filteredUsers.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <p className="text-sm">No users found</p>
              </div>
            ) : (
              filteredUsers.map((u) => (
                <button
                  key={u.id}
                  onClick={() => handleSelectUser(u)}
                  className={`w-full text-left p-3 rounded-lg mb-2 transition-all touch-target ${
                    selectedUser?.id === u.id
                      ? 'bg-gradient-to-r from-teal-100 to-teal-50 border border-teal-200'
                      : 'hover:bg-slate-100 active:bg-slate-200'
                  }`}
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white font-semibold mr-3 flex-shrink-0">
                      {u.username.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-slate-900 truncate text-sm">{u.username}</p>
                      <p className="text-xs text-slate-500 truncate">{u.email}</p>
                    </div>
                    {u.status === 'online' && (
                      <div className="w-2 h-2 bg-green-500 rounded-full ml-2 flex-shrink-0 animate-pulse"></div>
                    )}
                  </div>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-white/30 backdrop-blur-sm overflow-hidden">
        {selectedUser ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-slate-200 bg-white/50 backdrop-blur-sm flex items-center justify-between safe-area-left safe-area-right">
              <div className="flex items-center flex-1 min-w-0">
                <button
                  onClick={handleBackToList}
                  className="md:hidden mr-3 touch-target text-slate-600 hover:text-slate-900"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white font-semibold mr-3 flex-shrink-0">
                  {selectedUser.username.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <p className="font-semibold text-slate-900 truncate text-sm">{selectedUser.username}</p>
                  <p className="text-xs text-slate-500">
                    {selectedUser.status === 'online' ? 'Online' : 'Offline'}
                  </p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-3 md:p-4 safe-area-left safe-area-right">
              <div className="space-y-4">
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-slate-500">
                    <p className="text-sm text-center">No messages yet. Start the conversation!</p>
                  </div>
                ) : (
                  Object.entries(groupedMessages).map(([date, dateMessages]) => (
                    <div key={date}>
                      <div className="flex items-center justify-center my-4">
                        <div className="flex-1 border-t border-slate-200"></div>
                        <span className="px-3 text-xs text-slate-500 bg-white/50 rounded-full">
                          {date}
                        </span>
                        <div className="flex-1 border-t border-slate-200"></div>
                      </div>

                      <div className="space-y-2">
                        {dateMessages.map((msg) => (
                          <div
                            key={msg.id}
                            className={`flex ${
                              msg.senderId === user.id ? 'justify-end' : 'justify-start'
                            }`}
                          >
                            <div
                              className={`max-w-xs px-3 md:px-4 py-2 rounded-lg text-sm ${
                                msg.senderId === user.id
                                  ? 'bg-gradient-to-br from-teal-500 to-teal-600 text-white rounded-br-none'
                                  : 'bg-white/70 backdrop-blur-sm text-slate-900 rounded-bl-none border border-slate-200'
                              }`}
                            >
                              {msg.senderId !== user.id && (
                                <p className="text-xs font-semibold text-slate-600 mb-1">
                                  {msg.senderName}
                                </p>
                              )}
                              <p className="break-words">{msg.text}</p>
                              <p
                                className={`text-xs mt-1 ${
                                  msg.senderId === user.id
                                    ? 'text-teal-100'
                                    : 'text-slate-500'
                                }`}
                              >
                                {formatTime(msg.timestamp)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-3 md:p-4 border-t border-slate-200 bg-white/50 backdrop-blur-sm safe-area-left safe-area-right safe-area-bottom">
              <div className="flex gap-2">
                <Input
                  ref={inputRef}
                  type="text"
                  placeholder="Type a message..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  disabled={sendingMessage}
                  className="flex-1 text-base touch-target"
                />
                <Button
                  type="submit"
                  disabled={sendingMessage || !messageText.trim()}
                  className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white touch-target"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col p-4">
            <div className="w-16 h-16 bg-gradient-to-br from-teal-100 to-teal-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Menu className="w-8 h-8 text-teal-600" />
            </div>
            <p className="text-slate-600 font-medium text-center">Select a user to start chatting</p>
            <button
              onClick={() => setShowUserList(true)}
              className="mt-4 md:hidden touch-target px-4 py-2 bg-teal-500 text-white rounded-lg"
            >
              Show Users
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
